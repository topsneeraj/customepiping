import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {Reversestr} from './reversestr';
import { AppComponent } from './app.component';
import {Subtitile} from './subtitile'
import { from } from 'rxjs';

@NgModule({
  declarations: [
    AppComponent,
    Reversestr,
    Subtitile
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
