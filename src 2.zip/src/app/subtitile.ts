import {Pipe,PipeTransform} from '@angular/core'
import { from } from "rxjs";
@Pipe({name:'subtitle'})

export class Subtitile  implements PipeTransform{

     
    transform(value:string,before:string,after :string) :string
    {
         var str =  before + " " +value+ " "+after;
         return str;

    }

}

